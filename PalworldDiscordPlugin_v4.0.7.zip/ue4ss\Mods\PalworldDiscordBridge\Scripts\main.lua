-- PalworldDiscordPlugin v4.0.7 - UE4SS Lua Bridge
-- Auto-installiert vom C++ Plugin. Nicht manuell bearbeiten.

local CONFIG = {
    dll_path = "PalworldDiscordPlugin.dll",
}

local function Log(msg)
    print("[Lua] [PalworldDiscordBridge] " .. msg)
end
local function Err(msg)
    print("[Lua] [PalworldDiscordBridge] ERROR: " .. msg)
end

-- ========================================================================
-- DLL Exports
-- ========================================================================
local EVENTS = { chat = true, join = true, leave = true, death = true }
local PERF  = { enabled = true, target_fps = 120 }
local BRIDGE_FILE = "ue4ss/Mods/PalworldDiscordBridge/dlls/PalDiscordBridge_out.txt"
local BRIDGE_INCOMING_FILE = "ue4ss/Mods/PalworldDiscordBridge/dlls/PalDiscordBridge_in.txt"
local PLAYER_LOG_FILE = "PalworldDiscordConfig/player_log.txt"
local PLAYER_CACHE_FILE = "PalworldDiscordConfig/player_cache.json"
local ADMIN_RESULT_FILE = "PalworldDiscordConfig/admin_result.txt"

local function LoadConfig()
    local ok, json = pcall(require, "json")
    if not ok then
        Log("json module not available, using defaults")
        return
    end
    local path = "PalworldDiscordConfig/config.json"
    local f = io.open(path, "r")
    if not f then
        Log("config.json not found, using defaults")
        return
    end
    local content = f:read("*a")
    f:close()
    local ok2, data = pcall(json.decode, content)
    if ok2 and data then
        if data.events then
            if data.events.chat  ~= nil then EVENTS.chat  = data.events.chat  end
            if data.events.join  ~= nil then EVENTS.join  = data.events.join  end
            if data.events.leave ~= nil then EVENTS.leave = data.events.leave end
            if data.events.death ~= nil then EVENTS.death = data.events.death end
            Log("Config loaded: chat=" .. tostring(EVENTS.chat) .. " join=" .. tostring(EVENTS.join) .. " leave=" .. tostring(EVENTS.leave) .. " death=" .. tostring(EVENTS.death))
        end
        if data.server_performance then
            local sp = data.server_performance
            if sp.enabled    ~= nil then PERF.enabled    = sp.enabled    end
            if sp.target_fps ~= nil then PERF.target_fps = sp.target_fps end
        end
    else
        Log("Config parse failed, using defaults")
    end
end

-- ========================================================================
-- Player Cache & Logging (for admin commands)
-- ========================================================================
local player_cache = {}   -- name -> {uid=..., steam_id=..., platform_id=...}
local player_cache_by_uid = {} -- uid -> name

local function WriteTextFile(path, content)
    local f = io.open(path, "a")
    if not f then
        Err("Cannot write file: " .. path)
        return false
    end
    f:write(content)
    f:close()
    return true
end

local function WritePlayerLog(name, uid, steam_id, platform_id)
    local line = os.date("%Y-%m-%d %H:%M:%S") .. " | "
        .. "name=" .. (name or "") .. " | "
        .. "uid=" .. (uid or "") .. " | "
        .. "steam_id=" .. (steam_id or "") .. " | "
        .. "platform_id=" .. (platform_id or "") .. "\n"
    WriteTextFile(PLAYER_LOG_FILE, line)
end

local function SavePlayerCache()
    local ok, json = pcall(require, "json")
    if not ok then return end
    local f = io.open(PLAYER_CACHE_FILE, "w")
    if not f then return end
    local data = {}
    for name, info in pairs(player_cache) do
        data[name] = info
    end
    local ok2, txt = pcall(json.encode, data)
    if ok2 and txt then
        f:write(txt)
    end
    f:close()
end

local function LoadPlayerCache()
    local ok, json = pcall(require, "json")
    if not ok then return end
    local f = io.open(PLAYER_CACHE_FILE, "r")
    if not f then return end
    local content = f:read("*a")
    f:close()
    local ok2, data = pcall(json.decode, content)
    if ok2 and data then
        for name, info in pairs(data) do
            player_cache[name] = info
            if info.uid then player_cache_by_uid[info.uid] = name end
        end
    end
end

-- ========================================================================
-- Server Performance Optimization
-- ========================================================================
local function ApplyServerOptimizations()
    if not PERF.enabled then
        Log("Server performance optimization disabled in config")
        return
    end
    if not ExecuteConsoleCommand then
        Log("ExecuteConsoleCommand not available - skipping performance optimization")
        return
    end
    local fps = tostring(PERF.target_fps)
    local cmds = {
        "t.MaxFPS " .. fps,              -- Cap/uncap server FPS
        "p.MaxSubstepDeltaTime 0.01",    -- Physics substep: 100 Hz max
        "net.MaxRPCPerNetUpdate 64",     -- More RPCs per network tick
        "net.MaxRepArraySize 65535",     -- Allow larger replicated arrays
        "net.MaxRepArrayMemory 65535",   -- Increase replicated array memory
        "ai.SpawnCycle 0.1",             -- Reduce AI spawn/update cycle
        "wp.Runtime.MaxConsecutiveOverdueFrames 10", -- WorkGraph tolerance
    }
    local ok_count = 0
    for _, cmd in ipairs(cmds) do
        local ok = pcall(ExecuteConsoleCommand, cmd)
        if ok then ok_count = ok_count + 1 end
        Log("PerfCmd [" .. (ok and "OK" or "ERR") .. "]: " .. cmd)
    end
    Log("Server performance optimization done (" .. ok_count .. "/" .. #cmds .. " cmds, target=" .. fps .. " fps)")
end

local function WriteBridge(eventType, player, msg)
    local line = eventType .. "|" .. (player or "") .. "|" .. (msg or "") .. "\n"
    local f = io.open(BRIDGE_FILE, "a")
    if f then
        f:write(line)
        f:close()
    else
        Err("Cannot write bridge file")
    end
end

-- Read incoming Discord messages (C++ writes, Lua reads)
local function ReadIncomingBridge()
    local f = io.open(BRIDGE_INCOMING_FILE, "r")
    if not f then return end
    local content = f:read("*a")
    f:close()
    os.remove(BRIDGE_INCOMING_FILE)

    if not content or #content == 0 then return end

    for line in content:gmatch("[^\r\n]+") do
        local p1 = line:find("|")
        local p2 = p1 and line:find("|", p1 + 1)
        if p1 and p2 then
            local event = line:sub(1, p1 - 1)
            local sender = line:sub(p1 + 1, p2 - 1)
            local msg = line:sub(p2 + 1)
            if event == "discord" and sender and msg and #msg > 0 then
                Log("Discord->Game: [" .. sender .. "]: " .. msg)
                BroadcastSystemMessage("[Discord] " .. sender .. ": " .. msg)
            end
        end
    end
end

-- ========================================================================
-- Chat Hook: /Script/Pal.PalGameStateInGame:BroadcastChatMessage
-- ========================================================================
local chatHooked = false
local function RegisterChatHook()
    if chatHooked then return true end

    local ok, preId, postId = pcall(RegisterHook,
        "/Script/Pal.PalGameStateInGame:BroadcastChatMessage",
        function(self, ChatMessage)
            local ok2, sender, message = pcall(function()
                local chat = ChatMessage:get()
                local s = chat.Sender:ToString()
                local m = chat.Message:ToString()
                return s, m
            end)
            if ok2 and sender and message and #message > 0 then
                if EVENTS.chat then
                    -- Filter system messages (empty sender = PalDefender/system)
                    if sender == "" or sender:find("SYSTEM") then
                        Log("System message filtered: " .. message:sub(1, 50))
                    else
                        Log("Chat: [" .. sender .. "]: " .. message)
                        WriteBridge("chat", sender, message)
                        Log("Chat bridged to file")
                    end
                else
                    Log("Chat event disabled, skipping")
                end
            end
        end)

    if ok and preId then
        chatHooked = true
        Log("ChatHook OK (BroadcastChatMessage)")
        return true
    else
        Err("ChatHook failed: " .. tostring(preId))
        return false
    end
end

-- ========================================================================
-- Player Join/Leave tracking (persisted in _G to survive mod reloads)
-- ========================================================================
if not _G.PalDiscord_online_players then _G.PalDiscord_online_players = {} end
if not _G.PalDiscord_join_recent then _G.PalDiscord_join_recent = {} end

local online_players = _G.PalDiscord_online_players
local join_recent = _G.PalDiscord_join_recent

local function IsPlayerOnline(name)
    return name and online_players[name] == true
end

local function MarkPlayerOnline(name)
    if name then online_players[name] = true end
end

local function MarkPlayerOffline(name)
    if name then online_players[name] = nil end
end

-- ========================================================================
-- Player ID Extraction Helpers (Steam/PlayerUID/Platform)
-- ========================================================================
local function TryGetPlayerUid(player_state)
    if not player_state then return nil end
    local variants = {
        function() return player_state.PlayerUId end,
        function()
            local id = player_state.IndividualId
            return id and id.PlayerUId
        end,
        function() return player_state.PlayerUID end,
        function() return player_state:GetName() end,
    }
    for _, fn in ipairs(variants) do
        local ok, v = pcall(fn)
        if ok and v then
            local s = tostring(v)
            if s ~= "" and s ~= "nil" then return s end
        end
    end
    return nil
end

local function TryGetSteamId(player_state)
    if not player_state then return nil end
    local variants = {
        function() return player_state:GetUniqueID() end,
        function() return player_state.UniqueNetId end,
        function()
            local id = player_state.UniqueNetId
            return id and (id.ToString and id:ToString() or tostring(id))
        end,
    }
    for _, fn in ipairs(variants) do
        local ok, v = pcall(fn)
        if ok and v then
            local s = tostring(v)
            local digits = s:match("(%d+)$")
            if digits and #digits >= 8 then return digits end
        end
    end
    return nil
end

local function TryGetPlatformId(player_state)
    if not player_state then return nil end
    local ok, v = pcall(function() return player_state.PlatformId end)
    if ok and v then return tostring(v) end
    ok, v = pcall(function() return player_state.PlatformUserId end)
    if ok and v then return tostring(v) end
    return nil
end

-- ========================================================================
-- Player Join Hook
-- ========================================================================
local joinHooked = _G.PalDiscord_joinHooked or false
local function RegisterJoinHook()
    if joinHooked then return true end
    joinHooked = true
    _G.PalDiscord_joinHooked = true

    -- Post-Hook: fires AFTER the function completes (no disconnects)
    local ok, preId, postId = pcall(RegisterHook,
        "/Script/Engine.PlayerController:ServerAcknowledgePossession",
        nil, -- no pre-hook (prevents disconnects)
        function(Context, Pawn)
            ExecuteWithDelay(3000, function()
                local pc = nil
                local ps = nil
                local ok2, name = pcall(function()
                    pc = Context:get()
                    if not pc or not pc:IsValid() then return nil end
                    ps = pc.PlayerState
                    if ps and ps:IsValid() then
                        return ps:GetPlayerName():ToString()
                    end
                    return nil
                end)
                -- Extract and log player IDs regardless of duplicate checks
                if ps and ps:IsValid() then
                    local uid = TryGetPlayerUid(ps)
                    local steam_id = TryGetSteamId(ps)
                    local platform_id = TryGetPlatformId(ps)
                    if name and uid then
                        player_cache[name] = { uid = uid, steam_id = steam_id or "", platform_id = platform_id or "" }
                        player_cache_by_uid[uid] = name
                        WritePlayerLog(name, uid, steam_id, platform_id)
                        SavePlayerCache()
                        Log("Player ID logged: name=" .. name .. " uid=" .. uid .. " steam_id=" .. (steam_id or "") .. " platform_id=" .. (platform_id or ""))
                    end
                end
                if ok2 and name and #name > 0 then
                    -- Trim whitespace
                    name = name:match("^%s*(.-)%s*$") or name
                    -- Ignore IP-address-like names (early connection before username is set)
                    if name:match("^%d+%.%d+%.%d+%.%d+$") or name:match("%d+%.%d+%.%d+%.%d+") then
                        Log("Join ignored (IP address): " .. name)
                        return
                    end
                    -- Skip if already known online (prevents repossession spam every few minutes)
                    if IsPlayerOnline(name) then
                        Log("Join ignored (already online): " .. name)
                        return
                    end
                    -- deduplicate: same player within 300s
                    local now = os.time()
                    if not join_recent[name] or (now - join_recent[name]) > 300 then
                        join_recent[name] = now
                        MarkPlayerOnline(name)
                        if EVENTS.join then
                            Log("Join: " .. name)
                            WriteBridge("join", name, "")
                        else
                            Log("Join event disabled, skipping")
                        end
                    else
                        Log("Join dedup: " .. name)
                    end
                end
            end)
        end)

    if ok and postId then
        joinHooked = true
        Log("JoinHook OK (ServerAcknowledgePossession POST-HOOK + 3s delay)")
        return true
    else
        Log("JoinHook not available (" .. tostring(postId) .. ")")
        return false
    end
end

-- ========================================================================
-- Player Death Hook
-- ========================================================================
local deathHooked = false
local function RegisterDeathHook()
    if deathHooked then return true end

    local hooks = {
        "/Script/Pal.PalGameStateInGame:OnPlayerDied",
        "/Script/Pal.PalCharacter:OnDeath",
    }

    for _, hookPath in ipairs(hooks) do
        local ok, preId, postId = pcall(RegisterHook, hookPath,
            function(self, Param)
                local ok2, name = pcall(function()
                    -- Try PlayerState directly
                    local ps = Param:get()
                    if ps and ps:IsValid() and ps.GetPlayerName then
                        return ps:GetPlayerName():ToString()
                    end
                    -- Fallback: try getting from self (the game state)
                    local gs = self:get()
                    if gs and gs:IsValid() then
                        -- OnPlayerDied might have different params
                        -- Try to extract from the param as UObject
                        local obj = Param:get()
                        if obj and obj:IsValid() then
                            if obj.GetPlayerName then
                                return obj:GetPlayerName():ToString()
                            end
                        end
                    end
                    return nil
                end)
                if ok2 and name and #name > 0 then
                    if EVENTS.death then
                        Log("Death: " .. name)
                        WriteBridge("death", name, "")
                    else
                        Log("Death event disabled, skipping")
                    end
                else
                    Log("DeathHook: could not extract name from " .. hookPath)
                end
            end)
        if ok then
            deathHooked = true
            Log("DeathHook OK (" .. hookPath .. ")")
            return true
        end
    end

    Log("DeathHook not available")
    return false
end
-- ========================================================================
-- Player Leave Hook
-- ========================================================================
if not _G.PalDiscord_leave_recent then _G.PalDiscord_leave_recent = {} end
local leave_recent = _G.PalDiscord_leave_recent
local leaveHooked = _G.PalDiscord_leaveHooked or false
local function RegisterLeaveHook()
    if leaveHooked then return true end
    leaveHooked = true
    _G.PalDiscord_leaveHooked = true

    -- Try various disconnect hooks
    local hooks = {
        "/Script/Pal.PalGameStateInGame:OnRemovePlayer",
        "/Script/Pal.PalGameStateInGame:OnLogout",
    }

    for _, hookPath in ipairs(hooks) do
        local ok, preId, postId = pcall(RegisterHook, hookPath,
            function(self, Param)
                local ok2, name = pcall(function()
                    -- Try PlayerState directly
                    local ps = Param:get()
                    if ps and ps:IsValid() and ps.GetPlayerName then
                        return ps:GetPlayerName():ToString()
                    end
                    -- Fallback: OnRemovePlayer sometimes passes Controller
                    local ctrl = Param:get()
                    if ctrl and ctrl:IsValid() then
                        if ctrl.PlayerState and ctrl.PlayerState:IsValid() then
                            return ctrl.PlayerState:GetPlayerName():ToString()
                        end
                        if ctrl.GetPlayerName then
                            return ctrl.GetPlayerName():ToString()
                        end
                    end
                    return nil
                end)
                if ok2 and name and #name > 0 then
                    name = name:match("^%s*(.-)%s*$") or name
                    -- Only emit leave if player was previously known online
                    if not IsPlayerOnline(name) then
                        Log("Leave ignored (not online): " .. name)
                        return
                    end
                    -- deduplicate: same player within 300s
                    local now = os.time()
                    if leave_recent[name] and (now - leave_recent[name]) <= 300 then
                        Log("Leave dedup: " .. name)
                        return
                    end
                    leave_recent[name] = now
                    MarkPlayerOffline(name)
                    if EVENTS.leave then
                        Log("Leave: " .. name)
                        WriteBridge("leave", name, "")
                    else
                        Log("Leave event disabled, skipping")
                    end
                else
                    Log("LeaveHook: could not extract name from " .. hookPath)
                end
            end)
        if ok then
            Log("LeaveHook OK (" .. hookPath .. ")")
            return true
        end
    end

    Log("LeaveHook not available")
    return false
end

-- ========================================================================
-- Ingame System Message via Broadcast (rcon)
-- ========================================================================
function BroadcastSystemMessage(text)
    -- Use UE4SS ExecuteConsoleCommand if available
    if ExecuteConsoleCommand then
        local ok = pcall(ExecuteConsoleCommand, "Broadcast " .. text)
        if ok then
            Log("System message sent (ExecuteConsoleCommand): " .. text)
            return true
        end
    end

    -- Fallback: get player controller and use ConsoleCommand
    local ok, pc = pcall(FindFirstOf, "PalPlayerController")
    if ok and pc and pc:IsValid() then
        local ok2 = pcall(function()
            pc:ConsoleCommand("Broadcast " .. text, true)
        end)
        if ok2 then
            Log("System message sent (ConsoleCommand): " .. text)
            return true
        end
    end

    -- Fallback 2: try any PlayerController
    local ok3, allPC = pcall(FindAllOf, "PlayerController")
    if ok3 and allPC then
        for _, p in pairs(allPC) do
            if p and p:IsValid() then
                local ok4 = pcall(function()
                    p:ConsoleCommand("Broadcast " .. text, true)
                end)
                if ok4 then
                    Log("System message sent (FindAllOf): " .. text)
                    return true
                end
            end
        end
    end

    Log("System message could not be sent - no player controller available")
    return false
end
-- ========================================================================
-- Admin Tools: Player lookup, base deletion, account deletion
-- ========================================================================
local function ResolvePlayer(input)
    if not input then return nil, nil end
    input = input:match("^%s*(.-)%s*$")
    if #input == 0 then return nil, nil end
    -- Direct UID?
    if input:match("^[0-9A-Fa-f%-]+") and #input > 16 then
        return input, player_cache_by_uid[input]
    end
    -- Cached by name?
    if player_cache[input] then
        return player_cache[input].uid, input
    end
    -- Cached by steam_id?
    for name, info in pairs(player_cache) do
        if info.steam_id and info.steam_id == input then
            return info.uid, name
        end
    end
    -- Try to find online player by name
    local ok, all_pc = pcall(FindAllOf, "PlayerController")
    if ok and all_pc then
        for _, pc in pairs(all_pc) do
            if pc and pc:IsValid() then
                local ps = pc.PlayerState
                if ps and ps:IsValid() then
                    local pname = ps:GetPlayerName():ToString()
                    if pname:lower() == input:lower() then
                        return TryGetPlayerUid(ps), pname
                    end
                end
            end
        end
    end
    return nil, nil
end

local function FindPlayerGuildId(player_uid)
    local ps_classes = { "PalPlayerState", "BP_PalPlayerState_C" }
    for _, cls in ipairs(ps_classes) do
        local ok, states = pcall(FindAllOf, cls)
        if ok and states then
            for _, ps in pairs(states) do
                local uid = TryGetPlayerUid(ps)
                if uid and uid == player_uid then
                    local ok_g, gid = pcall(function() return ps.GuildId or ps.GroupId or ps.GuildID end)
                    if ok_g and gid then return tostring(gid) end
                end
            end
        end
    end
    return nil
end

local function DestroyPlayerBuildObjects(player_uid)
    local destroyed = 0
    local guild_id = FindPlayerGuildId(player_uid)
    local build_classes = {
        "BuildObject", "PalBuildObject", "BP_PalBuildObject_C",
        "PalBaseCampObject", "BP_PalBaseCamp_C", "PalBuildObjectBase",
    }
    for _, cls in ipairs(build_classes) do
        local ok, objects = pcall(FindAllOf, cls)
        if not ok or not objects then goto skip_class end
        for _, obj in pairs(objects) do
            local ok_v, valid = pcall(function() return obj:IsValid() end)
            if not ok_v or not valid then goto skip_obj end
            local owner_match = false
            if player_uid and player_uid ~= "" then
                local ok_o, owner = pcall(function()
                    return obj.BuildPlayerUId or obj.OwnerPlayerUId or obj.PlayerUId or obj.OwnerUID
                end)
                if ok_o and owner then
                    owner_match = (tostring(owner) == player_uid)
                end
            end
            if not owner_match and guild_id then
                local ok_g, gid = pcall(function() return obj.GuildId or obj.GroupId or obj.GuildID end)
                if ok_g and gid and tostring(gid) == guild_id then
                    owner_match = true
                end
            end
            if owner_match then
                local ok_d = pcall(function() obj:K2_DestroyActor() end)
                if ok_d then
                    destroyed = destroyed + 1
                    Log("Destroyed build object: " .. cls .. " (#" .. destroyed .. ")")
                end
            end
            ::skip_obj::
        end
        ::skip_class::
    end
    return destroyed
end

local function WriteAdminResult(text)
    WriteTextFile(ADMIN_RESULT_FILE, os.date("%Y-%m-%d %H:%M:%S") .. " | " .. text .. "\n")
end

-- ========================================================================
-- Main
-- ========================================================================
Log("v4.0.7 Lua Bridge")
Log("Hooks: Chat (BroadcastChatMessage), Join (POST-HOOK), Leave, Death")

-- Load event toggles from config.json
LoadConfig()
LoadPlayerCache()

-- Initialize C++ plugin (loads config, webhook, etc)
Log("Initializing C++ plugin...")
local startBridge = nil
local ok0, fn0 = pcall(package.loadlib, CONFIG.dll_path, "StartBridge")
if ok0 and fn0 then startBridge = fn0 end
if startBridge then
    local ok_init = pcall(startBridge)
    if ok_init then
        Log("C++ plugin initialized")
    else
        Err("C++ plugin init failed")
    end
else
    Err("StartBridge export not found")
end

Log("Using file bridge: " .. BRIDGE_FILE)

-- Register all UE4SS hooks (game -> Discord via file bridge)
Log("Registering hooks...")
RegisterChatHook()
RegisterJoinHook()
RegisterLeaveHook()
RegisterDeathHook()

-- Register RCON-accessible console commands
if RegisterConsoleCommandHandler then
    RegisterConsoleCommandHandler("paldiscord.reload", function(full_command, parameters, output_device)
        Log("Console command received: " .. full_command)
        local reload = nil
        local ok0, fn0 = pcall(package.loadlib, CONFIG.dll_path, "ReloadConfig")
        if ok0 and fn0 then reload = fn0 end
        if reload then
            local ok = pcall(reload)
            Log("ReloadConfig result: " .. tostring(ok))
            return true
        else
            Err("ReloadConfig export not found")
            return false
        end
    end)
    Log("Console command registered: paldiscord.reload")

    RegisterConsoleCommandHandler("paldiscord.delaccount", function(full_command, parameters, output_device)
        Log("Console command received: " .. full_command)
        local input = parameters[1] or ""
        local uid, name = ResolvePlayer(input)
        if not uid then
            local msg = "delaccount failed: could not resolve player: " .. input
            Err(msg)
            WriteAdminResult(msg)
            return false
        end
        local delsave = nil
        local ok0, fn0 = pcall(package.loadlib, CONFIG.dll_path, "DeletePlayerSave")
        if ok0 and fn0 then delsave = fn0 end
        if not delsave then
            local msg = "delaccount failed: DeletePlayerSave export not found"
            Err(msg)
            WriteAdminResult(msg)
            return false
        end
        local ok = pcall(delsave, uid)
        local msg = "delaccount " .. (name or input) .. " (uid=" .. uid .. "): " .. (ok and "OK" or "FAILED")
        Log(msg)
        WriteAdminResult(msg)
        return ok
    end)
    Log("Console command registered: paldiscord.delaccount")

    RegisterConsoleCommandHandler("paldiscord.delbase", function(full_command, parameters, output_device)
        Log("Console command received: " .. full_command)
        local input = parameters[1] or ""
        local uid, name = ResolvePlayer(input)
        if not uid then
            local msg = "delbase failed: could not resolve player: " .. input
            Err(msg)
            WriteAdminResult(msg)
            return false
        end
        local count = 0
        if ExecuteInGameThread then
            ExecuteInGameThread(function()
                count = DestroyPlayerBuildObjects(uid)
            end)
        else
            count = DestroyPlayerBuildObjects(uid)
        end
        local msg = "delbase " .. (name or input) .. " (uid=" .. uid .. "): destroyed " .. count .. " build objects"
        Log(msg)
        WriteAdminResult(msg)
        return true
    end)
    Log("Console command registered: paldiscord.delbase")
else
    Log("RegisterConsoleCommandHandler not available - RCON commands disabled")
end

-- Start periodic reader for Discord->Game messages (C++ writes file, Lua reads)
Log("Starting Discord->Game bridge reader...")
if LoopAsync then
    LoopAsync(2000, function()
        ReadIncomingBridge()
    end)
else
    Log("LoopAsync not available - Discord->Game bridge will not work")
end

-- Apply server performance optimizations after game fully loads
if ExecuteWithDelay then
    ExecuteWithDelay(5000, ApplyServerOptimizations)
else
    ApplyServerOptimizations()
end

-- Send system message after short delay (allow game to fully load)
if ExecuteWithDelay then
    ExecuteWithDelay(10000, function()
        BroadcastSystemMessage("Chat System online [Alpha]")
    end)
end

Log("Ready.")
