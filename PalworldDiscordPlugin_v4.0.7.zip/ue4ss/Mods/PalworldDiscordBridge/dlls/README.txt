Dieser Ordner wird zur Laufzeit fuer die Datei-Bridge zwischen Lua und dem C++-Plugin verwendet.
Die Dateien PalDiscordBridge_in.txt und PalDiscordBridge_out.txt werden hier automatisch erstellt.
