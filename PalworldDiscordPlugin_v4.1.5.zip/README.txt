PalworldDiscordPlugin v4.1.5
================================================

INSTALLATION (3 Schritte)
--------------------------

SCHRITT 1: Dateien entpacken
  Entpacke den Inhalt dieses ZIPs in deinen Ordner:
    Pal\Binaries\Win64\

  Ergebnis:
    Win64\PalworldDiscordPlugin.dll
    Win64\PalworldDiscordConfig\config.json
    Win64\ue4ss\Mods\PalworldDiscordBridge\


SCHRITT 2: Mod aktivieren
  Oeffne:  Win64\ue4ss\Mods\mods.txt
  Fuege am Ende ein:

    PalworldDiscordBridge : 1

  Speichern und schliessen.


SCHRITT 3: Webhook eintragen
  Oeffne:  Win64\PalworldDiscordConfig\config.json
  Trage deine Discord-Webhook-URL ein:

    "webhook_url": "https://discord.com/api/webhooks/DEINE_URL_HIER"

  Speichern.


SCHRITT 4: Server starten
  Starte den Palworld-Server. Fertig.
  Der erste Start erstellt alle fehlenden Dateien automatisch.


FEHLERBEHEBUNG
--------------
  Log:      Win64\PalworldDiscordPlugin.log
  Pruefen:  mods.txt enthaelt "PalworldDiscordBridge : 1"
  Pruefen:  PalworldDiscordConfig\config.json enthaelt korrekte webhook_url


FEATURES
--------
  - Chat (Spiel -> Discord)
  - Beitritt / Verlassen / Tod als Discord-Embed
  - Discord -> Spiel (bot_token + channel_id konfigurieren)
  - Alle Ereignisse einzeln aktivierbar (events in config.json)
  - Automatische Selbst-Installation beim Start


VERSION
-------
  v4.1.5 - PalworldDiscordConfig Edition
  Copyright 2026 RL-Dev.de