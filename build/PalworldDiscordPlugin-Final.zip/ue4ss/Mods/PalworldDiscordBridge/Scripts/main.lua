-- PalworldDiscordPlugin - UE4SS Lua Bridge v1.1 (Wine/Proton Fixed)
local CONFIG = {
    bridge_in_file  = "PalDiscordBridge_in.txt",
    bridge_out_file = "PalDiscordBridge_out.txt",
    dll_paths = {
        "ue4ss/Mods/PalworldDiscordBridge/dlls/PalworldDiscordPlugin.dll",
        "Mods/PalworldDiscordBridge/dlls/PalworldDiscordPlugin.dll",
        "PalworldDiscordPlugin.dll",
    },
    chat_function_hint = "",
    message_property = "Message",
    sender_property  = "SenderName",
    send_chat_function_hint = "",
    poll_interval = 500,
    discord_prefix = "[Discord] ",
    hook_retry_delay = 5000,
    hook_max_retries = 60,
}

local function Log(msg)
    print("[PalworldDiscordBridge] " .. msg)
end
local function Err(msg)
    print("[PalworldDiscordBridge] ERROR: " .. msg)
end
local function Dbg(msg)
    print("[PalworldDiscordBridge] DBG: " .. msg)
end

-- Spiel-Root finden
local game_root = nil
local function GetGameRoot()
    if game_root then return game_root end
    if IterateGameDirectories then
        local dirs = IterateGameDirectories()
        if dirs and dirs.Game then
            game_root = dirs.Game.__absolute_path
            Dbg("Game Root = " .. game_root)
            return game_root
        end
    end
    return "."
end

-- DLL laden - probiere mehrere Pfade
local function LoadPlugin()
    local root = GetGameRoot()
    Log("Suche DLL (Game Root: " .. tostring(root) .. ")")

    for _, rel_path in ipairs(CONFIG.dll_paths) do
        local paths_to_try = {
            rel_path,
            root .. "/" .. rel_path,
        }
        -- Wine: ersetze / durch \ fuer package.loadlib
        for _, p in ipairs(paths_to_try) do
            local wine_path = p:gsub("/", "\\")
            Dbg("Versuche: " .. p)
            -- Pruefe ob Datei existiert
            local f = io.open(p, "rb")
            if f then
                f:close()
                Dbg("Datei existiert: " .. p)
                local ok, loader = pcall(package.loadlib, wine_path, "StartBridge")
                if ok and type(loader) == "function" then
                    Log("DLL gefunden in: " .. p)
                    local call_ok, result = pcall(loader)
                    if call_ok then
                        Log("DLL geladen (StartBridge OK)")
                    else
                        Log("DLL geladen (StartBridge Fehler: " .. tostring(result) .. ")")
                    end
                    return true
                elseif ok and not loader then
                    Dbg("package.loadlib ok aber loader=nil")
                else
                    Dbg("package.loadlib fehlgeschlagen: " .. tostring(loader))
                end
            else
                Dbg("Datei nicht gefunden: " .. p)
            end
        end
    end

    Err("DLL konnte in KEINEM Pfad geladen werden.")
    Err("Ueberpruefe, ob PalworldDiscordPlugin.dll existiert.")
    return false
end

-- Bridge I/O
local last_in_offset = 0
local function WriteBridgeOut(author, message)
    local f = io.open(CONFIG.bridge_out_file, "a")
    if not f then return end
    local a = author:gsub("[\t\n\r]", " ")
    local m = message:gsub("[\t\n\r]", " ")
    f:write(a .. "\t" .. m .. "\n")
    f:close()
end

local function ReadBridgeIn()
    local f = io.open(CONFIG.bridge_in_file, "r")
    if not f then return nil end
    local size = f:seek("end")
    if size < last_in_offset then last_in_offset = 0 end
    if size == last_in_offset then f:close() return nil end
    f:seek("set", last_in_offset)
    local data = f:read("*a")
    last_in_offset = size
    f:close()
    local lines = {}
    for line in data:gmatch("([^\r\n]+)") do
        if #line > 0 then table.insert(lines, line) end
    end
    return lines
end

-- Chat Hook
local function OnChatMessage(context, params)
    local msg = ""
    local sender = "Player"
    if params and params.Message then
        msg = params.Message:ToString() or ""
    elseif params and params.ChatMessage then
        msg = params.ChatMessage:ToString() or ""
    elseif params and params.Text then
        msg = params.Text:ToString() or ""
    end
    if params and params.SenderName then
        sender = params.SenderName:ToString() or "Player"
    elseif params and params.PlayerName then
        sender = params.PlayerName:ToString() or "Player"
    elseif params and params.Sender then
        sender = params.Sender:ToString() or "Player"
    elseif context then
        sender = context:GetName() or "Player"
    end
    if msg and #msg > 0 then
        WriteBridgeOut(sender, msg)
    end
end

local function FindChatFunction(hint)
    if not hint or hint == "" then return nil end
    if not ForEachUObject then return nil end
    local candidates = {}
    local ok = pcall(function()
        ForEachUObject(function(obj)
            if obj:type() == "UFunction" then
                local name = obj:GetName()
                if name:find(hint, 1, true) then
                    table.insert(candidates, name)
                end
            end
        end)
    end)
    if not ok then return nil end
    if #candidates > 0 then
        Log("Gefunden: " .. table.concat(candidates, ", "))
        return candidates[1]
    end
    return nil
end

local registered_hooks = {}
local function RegisterChatHook()
    local func_name = CONFIG.chat_function_hint
    if not func_name or func_name == "" then
        local hints = { "Chat", "Say", "Message", "SendChat", "ReceiveChat", "ServerSay", "ChatToServer" }
        for _, h in ipairs(hints) do
            func_name = FindChatFunction(h)
            if func_name then
                Log("Auto-Scan: " .. func_name)
                break
            end
        end
    end
    if not func_name or func_name == "" then
        return false, "Keine Chat-Funktion gefunden"
    end
    Log("Hook: " .. func_name)
    local pre_id, post_id = RegisterHook(func_name, function(self, params)
        Log("HOOK TRIGGERED: " .. func_name)
        local ok, err = pcall(function()
            local actual_params = params:get()
            if actual_params then
                OnChatMessage(self, actual_params)
            else
                Log("params:get() returned nil")
            end
        end)
        if not ok then
            Log("Hook callback error: " .. tostring(err))
        end
    end)
    table.insert(registered_hooks, { name = func_name, pre = pre_id, post = post_id })
    Log("Hook OK (pre=" .. tostring(pre_id) .. ")")
    return true
end

-- Verzoegerter Chat-Hook (Retry)
local function StartDelayedHookRegistration()
    Log("Starte verzoegerte Hook-Registrierung...")
    local retries = 0
    LoopAsync(CONFIG.hook_retry_delay, function()
        retries = retries + 1
        if retries > CONFIG.hook_max_retries then
            Err("Hook-Registrierung nach " .. CONFIG.hook_max_retries .. " Versuchen abgebrochen.")
            return true -- stop
        end
        Dbg("Hook-Versuch #" .. retries)
        local ok, err = pcall(RegisterChatHook)
        if ok then
            Log("Chat-Hook erfolgreich registriert (Versuch " .. retries .. ")")
            return true -- stop
        else
            Dbg("Hook fehlgeschlagen: " .. tostring(err))
            return false -- retry
        end
    end)
end

-- Send-Funktionen fuer Discord -> Spiel
local send_function_ref = nil
local send_target_ref   = nil
local function FindSendChatFunction()
    local hint = CONFIG.send_chat_function_hint
    if not hint or hint == "" then hint = "Say" end
    if not ForEachUObject then return nil end
    local candidates = {}
    local ok = pcall(function()
        ForEachUObject(function(obj)
            if obj:type() == "UFunction" then
                local name = obj:GetName()
                if name:find(hint, 1, true) then
                    table.insert(candidates, { name = name, obj = obj })
                end
            end
        end)
    end)
    if not ok or #candidates == 0 then return nil end
    Log("Send-Kandidat: " .. candidates[1].name)
    return candidates[1].obj
end

local function FindSendTarget(func)
    if not func then return nil end
    local outer = func:GetOuter()
    if not outer then return nil end
    local class_name = outer:GetName()
    local target = FindFirstOf(class_name)
    return target
end

local function BroadcastToGame(author, message)
    if not send_function_ref then
        send_function_ref = FindSendChatFunction()
        if send_function_ref then
            send_target_ref = FindSendTarget(send_function_ref)
        end
    end
    if not send_function_ref or not send_target_ref then
        Dbg("Kein Send-Ziel. Verworfen: " .. author .. ": " .. message)
        return false
    end
    local full_msg = CONFIG.discord_prefix .. author .. ": " .. message
    ExecuteInGameThread(function()
        local params = {}
        params.Message = full_msg
        params.ChatMessage = full_msg
        params.Text = full_msg
        local ok, err = pcall(function()
            send_target_ref:CallFunction(send_function_ref, params)
        end)
        if not ok then Err("Injection: " .. tostring(err)) end
    end)
    return true
end

-- Bridge Loop
local function StartBridgeLoop()
    Log("Bridge-Loop gestartet")
    LoopAsync(CONFIG.poll_interval, function()
        local lines = ReadBridgeIn()
        if lines then
            for _, line in ipairs(lines) do
                local tab_pos = line:find("\t")
                local author, message
                if tab_pos then
                    author = line:sub(1, tab_pos - 1)
                    message = line:sub(tab_pos + 1)
                else
                    author = "Discord"
                    message = line
                end
                BroadcastToGame(author, message)
            end
        end
        return false
    end)
end

-- Haupt-Start
Log("PalworldDiscordPlugin Lua Bridge v1.1")
Log("Game Root: " .. tostring(GetGameRoot()))

local dll_loaded = LoadPlugin()
if not dll_loaded then
    Log("Lua-Only Modus (DLL nicht geladen)")
end

StartDelayedHookRegistration()
StartBridgeLoop()
Log("Bereit. Warte auf Spiel-Initialisierung...")
