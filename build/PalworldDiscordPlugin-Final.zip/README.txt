PalworldDiscordPlugin v1.1 - Wine/Proton Fix
============================================

NUR DATEIEN KOPIEREN - KEINE SKRIPTE NOTWENDIG

SCHRITT 1: Dateien kopieren
----------------------------
Kopiere diese Dateien in deinen Pal/Binaries/Win64 Ordner:

1. PalworldDiscordPlugin.dll         -> Win64/
2. config.json                       -> Win64/
3. Der ganze Ordner ue4ss/           -> Win64/ue4ss/

SCHRITT 2: Mod aktivieren
--------------------------
Oeffne die Datei Win64/ue4ss/Mods/mods.txt mit einem Texteditor.
Fuege am Ende dieser Datei eine neue Zeile ein:

    PalworldDiscordBridge : 1

SCHRITT 3: Discord-Webhook eintragen
-------------------------------------
Oeffne die Datei Win64/config.json mit einem Texteditor.
Trage deine Discord-Webhook-URL ein:

    "webhook_url": "https://discord.com/api/webhooks/DEINE_URL_HIER"

SCHRITT 4: Server starten
--------------------------
Starte den Palworld-Server neu. Fertig.

WICHTIG: HTTP-Server ist deaktiviert (http_port: 0)
---------------------------------------------------
Damit der Server unter Wine/Proton nicht crasht, ist der HTTP-Server
deaktiviert. Discord -> Spiel Nachrichten gehen ueber die Datei-Bridge:

Schreibe in die Datei PalDiscordBridge_in.txt:
    Spielername\tNachrichtentext

Beispiel:
    Bot\tHallo aus Discord!

Diese Nachricht erscheint dann im Spiel-Chat.

FEHLERBEHEBUNG
--------------
Wenn der Mod nicht geladen wird:
1. Pruefe mods.txt auf: PalworldDiscordBridge : 1
2. Aktiviere Debug-Mod in mods.txt: PalworldDiscordDebug : 1
3. Suche im Server-Log nach "[DEBUG]"
4. Alle "[OK]" = gut, "[X]" = Datei fehlt

DATEIEN
-------
PalworldDiscordPlugin.dll            -> Haupt-DLL
config.json                          -> Konfiguration
ue4ss/Mods/PalworldDiscordBridge/    -> Lua-Mod
ue4ss/Mods/PalworldDiscordDebug/     -> Debug-Mod (optional)
