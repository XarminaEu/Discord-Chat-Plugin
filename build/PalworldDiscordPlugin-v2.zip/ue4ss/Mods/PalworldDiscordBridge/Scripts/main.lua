-- PalworldDiscordPlugin v2.0 - Minimal Lua Loader
-- Die DLL macht ALLES (LogWatcher + Discord Webhook)
-- Dieses Lua-Skript laedt nur die DLL, der Rest passiert in C++

print("[PalworldDiscordBridge] v2.0 Minimal Loader")

local function LoadPlugin()
    local dll_paths = {
        "ue4ss/Mods/PalworldDiscordBridge/dlls/PalworldDiscordPlugin.dll",
        "Mods/PalworldDiscordBridge/dlls/PalworldDiscordPlugin.dll",
        "PalworldDiscordPlugin.dll",
    }

    for _, p in ipairs(dll_paths) do
        local wine_path = p:gsub("/", "\\")
        local f = io.open(p, "rb")
        if f then
            f:close()
            local ok, loader = pcall(package.loadlib, wine_path, "StartBridge")
            if ok and type(loader) == "function" then
                print("[PalworldDiscordBridge] DLL loaded from: " .. p)
                pcall(loader)
                return true
            end
        end
    end

    print("[PalworldDiscordBridge] ERROR: Could not load DLL")
    return false
end

LoadPlugin()
print("[PalworldDiscordBridge] Loader done - C++ plugin active")
