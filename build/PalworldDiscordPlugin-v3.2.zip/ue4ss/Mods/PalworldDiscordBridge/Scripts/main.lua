-- PalworldDiscordPlugin v3.2 - UE4SS Lua Bridge
-- Auto-installiert vom C++ Plugin. Nicht manuell bearbeiten.

local CONFIG = {
    dll_path = "ue4ss/Mods/PalworldDiscordBridge/dlls/PalworldDiscordPlugin.dll",
}

local function Log(msg)
    print("[Lua] [PalworldDiscordBridge] " .. msg)
end
local function Err(msg)
    print("[Lua] [PalworldDiscordBridge] ERROR: " .. msg)
end

local EVENTS = { chat = true, join = true, leave = true, death = true }
local BRIDGE_FILE = "ue4ss/Mods/PalworldDiscordBridge/dlls/PalDiscordBridge_out.txt"

local function LoadConfig()
    local ok, json = pcall(require, "json")
    if not ok then
        Log("json module not available, using defaults")
        return
    end
    local path = "ue4ss/Mods/PalworldDiscordBridge/dlls/config.json"
    local f = io.open(path, "r")
    if not f then
        Log("config.json not found, using defaults")
        return
    end
    local content = f:read("*a")
    f:close()
    local ok2, data = pcall(json.decode, content)
    if ok2 and data and data.events then
        if data.events.chat ~= nil then EVENTS.chat = data.events.chat end
        if data.events.join ~= nil then EVENTS.join = data.events.join end
        if data.events.leave ~= nil then EVENTS.leave = data.events.leave end
        if data.events.death ~= nil then EVENTS.death = data.events.death end
        Log("Config loaded: chat=" .. tostring(EVENTS.chat) .. " join=" .. tostring(EVENTS.join) .. " leave=" .. tostring(EVENTS.leave) .. " death=" .. tostring(EVENTS.death))
    else
        Log("Config parse failed, using defaults")
    end
end

local function WriteBridge(eventType, player, msg)
    local line = eventType .. "|" .. (player or "") .. "|" .. (msg or "") .. "\n"
    local f = io.open(BRIDGE_FILE, "a")
    if f then
        f:write(line)
        f:close()
    else
        Err("Cannot write bridge file")
    end
end

local chatHooked = false
local function RegisterChatHook()
    if chatHooked then return true end

    local ok, preId, postId = pcall(RegisterHook,
        "/Script/Pal.PalGameStateInGame:BroadcastChatMessage",
        function(self, ChatMessage)
            local ok2, sender, message = pcall(function()
                local chat = ChatMessage:get()
                local s = chat.Sender:ToString()
                local m = chat.Message:ToString()
                return s, m
            end)
            if ok2 and sender and message and #message > 0 then
                if EVENTS.chat then
                    if sender == "" or sender:find("SYSTEM") then
                        Log("System message filtered: " .. message:sub(1, 50))
                    else
                        Log("Chat: [" .. sender .. "]: " .. message)
                        WriteBridge("chat", sender, message)
                        Log("Chat bridged to file")
                    end
                else
                    Log("Chat event disabled, skipping")
                end
            end
        end)

    if ok and preId then
        chatHooked = true
        Log("ChatHook OK (BroadcastChatMessage)")
        return true
    else
        Err("ChatHook failed: " .. tostring(preId))
        return false
    end
end

local joinHooked = false
local function RegisterJoinHook()
    if joinHooked then return true end
    Log("JoinHook SKIPPED (causes disconnects)")
    return false
end

local leaveHooked = false
local function RegisterLeaveHook()
    if leaveHooked then return true end

    local hooks = {
        "/Script/Pal.PalGameStateInGame:OnRemovePlayer",
        "/Script/Pal.PalGameStateInGame:OnLogout",
    }

    for _, hookPath in ipairs(hooks) do
        local ok, preId, postId = pcall(RegisterHook, hookPath,
            function(self, PlayerState)
                local ok2, name = pcall(function()
                    local ps = PlayerState:get()
                    if ps and ps:IsValid() then
                        return ps:GetPlayerName():ToString()
                    end
                    return nil
                end)
                if ok2 and name and #name > 0 then
                    if EVENTS.leave then
                        Log("Leave: " .. name)
                        WriteBridge("leave", name, "")
                    else
                        Log("Leave event disabled, skipping")
                    end
                end
            end)
        if ok then
            leaveHooked = true
            Log("LeaveHook OK (" .. hookPath .. ")")
            return true
        end
    end

    Log("LeaveHook not available")
    return false
end

local deathHooked = false
local function RegisterDeathHook()
    if deathHooked then return true end

    local hooks = {
        "/Script/Pal.PalGameStateInGame:OnPlayerDied",
        "/Script/Pal.PalCharacter:OnDeath",
    }

    for _, hookPath in ipairs(hooks) do
        local ok, preId, postId = pcall(RegisterHook, hookPath,
            function(self, PlayerState)
                local ok2, name = pcall(function()
                    local ps = PlayerState:get()
                    if ps and ps:IsValid() then
                        return ps:GetPlayerName():ToString()
                    end
                    return nil
                end)
                if ok2 and name and #name > 0 then
                    if EVENTS.death then
                        Log("Death: " .. name)
                        WriteBridge("death", name, "")
                    else
                        Log("Death event disabled, skipping")
                    end
                end
            end)
        if ok then
            deathHooked = true
            Log("DeathHook OK (" .. hookPath .. ")")
            return true
        end
    end

    Log("DeathHook not available")
    return false
end

local function BroadcastSystemMessage(text)
    if ExecuteConsoleCommand then
        local ok = pcall(ExecuteConsoleCommand, "Broadcast " .. text)
        if ok then
            Log("System message sent: " .. text)
            return true
        end
    end

    local ok, pc = pcall(FindFirstOf, "PalPlayerController")
    if ok and pc and pc:IsValid() then
        local ok2 = pcall(function()
            pc:ConsoleCommand("Broadcast " .. text, true)
        end)
        if ok2 then
            Log("System message sent (ConsoleCommand): " .. text)
            return true
        end
    end

    Log("System message could not be sent")
    return false
end

Log("v3.2 Lua Bridge")
Log("Hooks: Chat (BroadcastChatMessage), Join (DISABLED), Leave, Death")

LoadConfig()

Log("Initializing C++ plugin...")
local startBridge = nil
local ok0, fn0 = pcall(package.loadlib, CONFIG.dll_path, "StartBridge")
if ok0 and fn0 then startBridge = fn0 end
if startBridge then
    local ok_init = pcall(startBridge)
    if ok_init then
        Log("C++ plugin initialized")
    else
        Err("C++ plugin init failed")
    end
else
    Err("StartBridge export not found")
end

Log("Using file bridge: " .. BRIDGE_FILE)

Log("Registering hooks...")
RegisterChatHook()
RegisterLeaveHook()
RegisterDeathHook()

ExecuteWithDelay(10000, function()
    BroadcastSystemMessage("Chat System online [Alpha]")
end)

Log("Ready.")
